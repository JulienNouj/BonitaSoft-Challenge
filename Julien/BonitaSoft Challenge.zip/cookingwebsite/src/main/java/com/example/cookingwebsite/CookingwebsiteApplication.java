package com.example.cookingwebsite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CookingwebsiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(CookingwebsiteApplication.class, args);
	}

}
